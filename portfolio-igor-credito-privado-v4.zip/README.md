Suba o conteúdo desta pasta no GitHub (raiz). Netlify: Import from Git → Publish directory = . → Build command vazio.
